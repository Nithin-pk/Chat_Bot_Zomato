## intent:affirm
- yes
- yep
- yeah
- indeed
- that's right
- ok
- great
- right, thank you
- correct
- great choice
- sounds really good
- thank- ya
- sure
- yeah
- ok
- cool
- go for it
- yep
- yep, will do thank you
- I'm sure I will!
- oh awesome!
- Yes
- accept
- I accept
- i accept
- ok i accept
- I changed my mind. I want to accept it
- ok cool
- alright
- i will!
- ok, I behave now
- yop
- oki doki
- yes please
- yes please!
- jo
- yep if i have to
- amayzing
- confirm
- nice
- coolio
- definitely yes without a doubt
- yas
- yup
- perfect
- sure thing
- absolutely
- Oh, ok
- Sure
- hm, i'd like that
- ja
- sure!
- yes i accept
- Sweet
- amazing!
- how nice!
- cool!
- yay
- yes accept please
- great
- oh cool
- yes
- fine
- i will take that
- that sounds just right
- nice choice
- ablusetly right
- great 
- nice
- amaze
- i like the choice of options
- grat optios
- great options
- cool choices

## intent:deny
- no
- nope
- definitely not
- never
- absolutely not
- i don't think so
- i'm afraid not
- no sir
- no ma'am
- no way
- no sorry
- No, not really.
- nah not for me
- nah
- no and no again
- no go
- no thanks
- decline
- deny
- i decline
- never mind
- nevermind
- I'm not giving you my email address
- no I haven't decided yet if I want to sign up
- I don't want to give it to you
- I'm not going to give it to you
- no i don't accept
- no!!!!
- no you did it wrong
- no i can't
- i'm not sure
- NEIN
- nein
- not really
- i guess it means - no
- i don't want to
- i don't want either of those
- nah thanks
- neither of these
- i don't like that option
- neither will work
- suggest some other option
- is this the best you can do
- nooooooo
-nonononooooo
- I dont agree
- disagree
- bad choice
- disagree

## intent:bye
- bye
- goodbye
- good bye
- stop
- end
- farewell
- Bye bye
- have a good on- goodnight
- good-bye
- good-night
- see ya
- toodle-oo
- bye bye
- gotta go
- farewell
- catch you later
- bye for now
- bye
- bye was nice talking to you
- bye udo
- bye bye bot
- bye bot
- k byyye #slay
- tlak to you later
- ciao
- Bye bye
- then bye
- tschüssikowski
- bye!
- cya
- bbbbye
- gne

## intent:greet
- hey
- howdy
- hey there
- hello
- hi
- good morning
- good evening
- dear sir
- Hi
- Hey
- Hi bot
- Hey bot
- Hello
- Good morning
- hi again
- hi folks
- hi Mister
- hi pal!
- hi there
- greetings
- hello everybody
- hello is anybody there
- hello robot
- hallo
- heeey
- hi hi
- hey
- hey hey
- hello there
- hi
- hello
- yo
- hola
- hi?
- hey bot!
- hello friend
- good morning
- hii
- hello sweet boy
- yoo
- hey there
- hiihihi
- hello sweatheart
- hellooo
- helloooo
- heyo
- ayyyy whaddup
- hello?
- Hallo
- heya
- hey bot
- howdy
- Hellllooooooo
- whats up
- Hei
- Well hello there ;)
- I said, helllllloooooO!!!!
- Heya
- Whats up my bot
- hiii
- heyho
- hey, let's talk
- hey let's talk
- jojojo
- hey dude
- hello it is me again
- what up
- hi there
- hi
- jop
- hi friend
- hi there it's me
- good evening
- good morning
- good afternoon

## intent:restaurant_search
- i'm looking for a place to eat
- I want to grab lunch
- I am searching for a dinner spot
- I am looking for some restaurants in [Delhi](location).
- I am looking for some restaurants in [Bangalore](location)
- show me [chinese](cuisine) restaurants
- show me [chines]{"entity": "cuisine", "value": "chinese"} restaurants in the [New Delhi]{"entity": "location", "value": "Delhi"}
- show me a [mexican](cuisine) place in the [centre](location)
- i am looking for an [indian](cuisine) spot called olaolaolaolaolaola
- search for restaurants
- anywhere in the [west](location)
- I am looking for [asian fusion](cuisine) food
- I am looking a restaurant in [294328](location)
- in [Gurgaon](location)
- [South Indian](cuisine)
- [North Indian](cuisine)
- [Italian](cuisine)
- [Chinese]{"entity": "cuisine", "value": "chinese"}
- [chinese](cuisine)
- [Lithuania](location)
- Oh, sorry, in [Italy](location)
- in [delhi](location)
- I am looking for some restaurants in [Mumbai](location)
- I am looking for [mexican indian fusion](cuisine)
- can you book a table in [rome](location) in a [moderate]{"entity": "budget", "value": "mid"} price range 
- can you book a table in [bombay](location) in a [low]{"entity": "budget", "value": "cheap"} price range
- [central](location) [indian](cuisine) restaurant
- please help me to find restaurants in [pune](location)
- Please find me a restaurantin [bangalore](location)
- [mumbai](location)
- show me restaurants
- please find me [chinese](cuisine) restaurant in [delhi](location)
- can you find me a [chinese](cuisine) restaurant
- [delhi](location)
- please find me a restaurant in [ahmedabad](location)
- please show me a few [italian](cuisine) restaurants in [bangalore](location- Find me a place to eat in Bangalore
- I need a new restaurant in Bengaluru
- Bhopal
- help me find restaurant in Bngalore
- Could you find me a restaurant to eat at bngalore?
- Bhubaneshwar
- Can you find me a restaurant in Bombay?
- Amritsar
- erode
- Jammu
- Kurnool
- Hey, help me find a restaurant in Mumbai
- I need to find a restaurant in Kolkata
- Pune
- Cyberabad
- calcuta
- Find a restaurant for me in Calcutta
- Where should I eat in Delhi?
- Delhi NCR
- Suggest me a good restaurant around New Delhi
- Bengaluru
- Amratsar
- I need to find this restaurant in Delhi
- Dilli
- Show me the closest open restaurant in Chennai
- Indore
- Jodhpur
- Hey help me find a restaurant in Madras
- Help me find a restaurant in Surat
- Recommend me a restaurant around Pune
- Goa
- Could you find a restaurant for me in Belgaum?
- Chandigarh
- Rajahmundry
- Ujjain
- Could you find a restaurant for me in Bengaluru?
- Would you find me a restaurant in Allahabad??
- vadodara
- Srinagar
- Could you find me a restaurant in Agra?
- Pick a restaurant for me, please in Kochi
- Mysuru
- How can you help me find a restaurant in Jamshedpur?
- Thrissur
- Can you find a restaurant for me in Chandigarh?
- Lucknow
- Would you find me a restaurant in Visakhapatnam??
- Could you find me a restaurant to eat at Gurgaon?
- NewDelhi
- Surat
- Jamshedpur
- Would you find me a restaurant in calcutta??
- Okay. Show me some in bengaluru
- Recommend me a restaurant around Prayagraj
- Rourkela
- Vijayawada
- Ajmer
- Allahabad
- raurkela
- Can you suggest some good restaurants in bombay
- I'm gonna need help finding a indian restaurant
- american
- i'm looking for a Chinese restaurant
- Hey, can you help me with locating a mexican restaurant
- i want a french restaurant
- chinese
- What's a good place to eat mexican food
- Find a restaurant for me where I can eat north indian
- Find a restaurant for me to eat mexican
- italian
- I am hungry, find me some place to go eat italian
- Would you find a south indian restaurant for me?
- Would you find a american restaurant
- north indian
- A place to eat chinase
- I want to eat italian food
- Please find me a south-indian restaurant
- south indian
- Quickly get me a northindian place
- Where can i get south-indina food?
- I need to find a restaurant southindian
- mexican
- A place to have italian food
- Suggest me a good mexican restaurant
- how can you help me find a french restaurant?
- italian
- I'm gonna need help finding a indian restaurant in Mysore
- i'm looking for a Chinese restaurant in Lucknow
- Hey, can you help me with locating a mexican restaurant in Lakhanpur
- i want a french restaurant in Vizag
- What's a good place to eat mexican food in Bangalore
- Find a restaurant for me where I can eat north indian in Jaipur
- Find a restaurant for me to eat mexican at Faridabad)
- tes-I am hungry, find me some place to go eat italian in Goa
- Would you find a south indian restaurant for me in Kozhikode?
- Would you find a american restaurant for me in Trivandrum?
- A place to eat chinase in Mysuru
- Hey, can you help me with locating a north indian restaurant in calcuta
- I want to eat italian food in cochin
- Please find me a south-indian restaurant in madras
- Quickly get me a northindian place in New Delhi
- Where can i get south-indina food in Mangaluru
- i'm looking for a Chinese restaurant in cyberabad
- chinese eating place in mumbai
- I want to eat italian food in Prayagraj
- Okay. I want to eat south indian in allahabad
- Okay. Show me some north indian restaurants in prayagraj
- What's a good place to eat mexican food in chandighar
- I need to find a restaurant
- Can you find me a good restaurant?
- Would you be able to search a place to eat?
- A place to have food
- Feeling hungry, can you help
- I am hungry, find a restaurant
- Get me some food quickly
- Pick some place for me to eat quickly
- Where can i get some food to eat
- i'm looking for a restaurant
- how can you help me find a restaurant
- pick a restaurant for me
- please find a restaurant for me
- I'm hungry. Looking out for some good restaurants
- I want to eat
- I am feeling hungry
- I need a new restaurant
- Suggest me a good restaurant
- where should i eat?
- I'm gonna need help finding a restaurant
- Show me an open restaurant
- Find a restaurant for me to eatt

## intent:out_of_scope
- I want pizza
- please help with my ice cream it's dripping
- no wait go back i want a dripping ice cream but a cone that catches it so you can drink the ice cream later
- i want a non dripping ice cream
- hey little mama let em whisper in your ear
- someone call the police i think the bot died
- show me a picture of a chicken
- neither
- I want french cuisine
- i am hungry
- restaurants
- restaurant
- you're a loser lmao
- can i be shown a gluten free restaurant
- i don't care!!!!
- i do not care how are you
- again?
- oh wait i gave you my work email address can i change it?
- hang on let me find it
- stop it, i do not care!!!
- really? you're so touchy?
- how come?
- I changed my mind
- what?
- did i break you
- I don't wanna tell the name of my company
- that link doesn't work!
- you already have that
- this is a really frustrating experience
- no stop
- i want a french restaurant
- shit bot
- do you want to marry me?
- give me food
- i want food
- udo, I want to marry you
- i wanna party
- shitmuncher
- I like you
- i want pizza
- i want pizza!!
- silly bot
- i want to eat
- you are a stupid bot
- i hate you
- Can I ask you questions first?
- is it a wasteland full of broken robot parts?
- i can't deal with your request
- are you vegan
- who will anser my email?
- do you sell vacuum robots?
- i want to buy a roomba for my grandson
- and make chicken noises into the phone
- is barbara still married to you
- what's your wife doing this weekend
- how are the kids
- you're rather dull
- personal or work?
- are you using Rasa Core and NLU ?
- tell me a joke
- what else?
- I already told you! I'm a shitmuncher
- I'm a shitmuncher
- who are the engineers at rasa?
- who are they?
- can we keep chatting?
- talk to me
- who is your favourite robot?
- a tamed mouse will arrive at your doorstep in the next couple of days
- you will know it from the single red rose it carries between its teeth
- i will tame a mouse for you
- isn't the newsletter just spam?
- go back
- can you help me with the docs?
- sorry, i cannot rephrase
- and your REST API doesn't work
- i told you already
- better than you
- oh my god, not again!
- you are a badass bot!
- lol
- why do you need that?
- is that any of your business
- can you help me with your docs?
- i immediately need help with implementing the coolest bot you can imagine
- can you help me with your docs
- can you tell me how to build a bot?
- can you learn from our conversation?
- common, just try
- hey, I contacted you a couple of days ago but didn't get any response, any news?
- please hurry, i have deadline in two weeks to deliver the bot it is for very big company
- you are annoying
- Do I have to accept?
- Is Rasa really smart?
- kannst du auch deutsch?
- are the newsletter worth the subscription?
- it's a pity
- i want more of you in my life!
- the one that is better than you
- you suck
- bots are bad
- i dont like bots
- do you have a phone number?
- where do you live?
- how are akela's cats doing?
- but I just told you that :(
- Why don’t you answer?
- But you're an english site :(
- can you help me to build a bot

## intent:thank
- Thanks
- Thank you
- Thank you so much
- Thanks bot
- Thanks for that
- cheers
- cheers bro
- ok thanks!
- perfect thank you
- thanks a bunch for everything
- thanks for the help
- thanks a lot
- amazing, thanks
- cool, thanks
- cool thank you
- thanks
- thanks!
- Cool. Thanks
- thanks
- thanks this is great news
- thank you
- great thanks
- Thanks!
- cool thanks
- thanks for  link, I'll check it out
- thanks!
- Thanks for the link,I'll go through it

## intent:ask_budget
- I want to eat at a place between 300 and 700
- I am fine with an expensive place
- I am looking for a dinner place at less than 300

## intent:ask_email
- can u mail me the information to abc@abc.com?{"entity": "email", "value": "abc@abc.com"}
- can u mail to test@tes.com?{"entity": "email", "value": "tes@tes.com"}
- can u mail me at test-123.456@dom.123.co.in?{"entity": "email", "value": "test-123.456@dom.123.co.in"}
- email address - test.some@gmail.co.in. Mail this list.{"entity": "email", "value": "test.some@gmail.co.in"}
- email me at email-123@domina.com{"entity": "email", "value": "email-123@domain.com"}
- mail me emial@domain.io{"entity": "email", "value": "email@domain.io"}
- my email address email.123-abc@domain.123.com{"entity": "email", "value": "123-abc@domain.123.com"}
- please mail me the list to 123-email@domain.co.in{"entity": "email", "value": "123-email@domain.co.in"}
- please send me the list to 123@domain.net{"entity": "email", "value": "123@domain.net"}
- please send this to email.123@123.456.com
- send this to abc-email@abc.com
- send to abc_123-email@abc123.com
- this is my email address - email-abc_123@abc.com.edu. send me an email.
- email1_34-ret@host-name.123.com
- can u share this information over email?
- can u send me an email?
- mail me the list
- email me a list of top 10 restaurants
- mail me the names of restaurants
- please send me an email
- please share this with me
- send me an email
- share some more restaurant names with me
- share this over mail
- share this information with me over email
- drop me an email-123@domina{"entity": "email", "value": "email-123@domain"}
- peri.sruti@gmail.com[]{"entity": "email", "value": "peri.sruti@gmail.com"}
- peri.sruti@gmail.com[]{"entity": "email", "value": "peri.sruti@gmail.com"}
- abc.def@gmail.com[]{"entity": "email", "value": "abc.def@gmail.com"}
- peri.sruti@gmail.com[]{"entity": "email", "value": "peri.sruti@gmail.com"}
- please mail to nithin.pk@sc.com[]{"entity": "email", "value": "nithin.pk@sc.com"}
- please mail to poppydatta@yahoo.com[]{"entity": "email", "value": "poppydatta@yahoo.com"}
- please provide detaials to peri.sruti@gmail.com[]{"entity": "email", "value": "peri.sruti@gmail.com"}
- please mail to abc.def@gmail.com[]{"entity": "email", "value": "abc.def@gmail.com"}
- drop an email

## lookup:location
- Bangalore
- Chennai
- Delhi
- Hyderabad
- Kolkata
- Mumbai
- Agra
- Ajmer
- Aligarh
- Allahabad
- Amravati
- Amritsar
- Asansol
- Ahmedabad
- Bareilly
- Belgaum
- Bhavnagar
- Bhiwandi
- Bhopal
- Bhubaneswar
- Bikaner
- Chandigarh
- Coimbatore
- Nagpur
- Cuttack
- Dehradun
- Dhanbad
- Durgapur
- Erode
- Faridabad
- Firozabad
- Gulbarga
- Guntur
- Gwalior
- Gurgaon
- Guwahati
- Indore
- Jabalpur
- Jaipur
- Jalandhar
- Jammu
- Jamnagar
- Jamshedpur
- Jhansi
- Jodhpur
- Kakinada
- Kannur
- Kanpur
- Kochi
- Kottayam
- Kolhapur
- Kollam
- Kozhikode
- Kurnool
- Lucknow
- Ludhiana
- Madurai
- Malappuram
- Mathura
- Goa
- Mangalore
- Meerut
- Moradabad
- Mysore
- Nanded
- Nashik
- Nellore
- Noida
- Palakkad
- Patna
- Pondicherry
- Pune
- Raipur
- Rajkot
- Rajahmundry
- Ranchi
- Rourkela
- Sangli
- Siliguri
- Solapur
- Srinagar
- Surat
- Thiruvananthapuram
- Thrissur
- Tiruchirappalli
- Tirunelveli
- Tiruppur
- Tiruvannamalai
- Ujjain
- Bijapur
- Vadodara
- Varanasi
- Vijayawada
- Visakhapatnam
- Vellore
- Warangal

## synonym:4
- four

## synonym:Delhi
- New Delhi
- Delhi
- NewDelhi
- Dilli
- Dellhi
- newdelhi
- Newdelhi
- new delhi
- new Delhi



## synonym:chinese
- chines
- Chinese
- Chines

## synonym:mid
- moderate
- midium
- middle

## synonym:low
- cheap
- economical
- econ
- low budget

## synonym:high
- costly
- high budget

## lookup:cuisine
- american
- chinese
- italian
- mexican
- north indian
- south indian

## synonym:italian
- Itlain
- Itlan
- itlan

## synonym:american
-american
-americn
-amrican
 
## synonym:mexican
-mexicn
-mexican
-mxican

## synonym:south indian
- south-indian
- southindian
- south-indina
- South Indian

## synonym:north indian
- north-indian
- northindian
- north-indina
- North Indian

## synonym:Bengaluru
- Bangalore
- bngalore
- bengalluru
- Bangalor
- bangalore
- bengaluru

## synonym:Kolkata
- Calcutta
- kolkata
- kolkatta
- calcutta
- calcuta


## synonym:Chennai
- chennai
- madras
- Madras
- chinai

## synonym:Hyderabad
- hyderabad
- Secunderabad
- secunderabad
- cyberabad
- Cyberabad

## synonym:Lucknow
-Lakhanpur

## synonym:Mysore
- mysore
- mysuru
- Mysuru

## synonym Kochi
- kochi
- cochin
- Cochin

## synonym:Mangalore
- mangalore
- mangaluru
- Mangaluru

## synonym:Visakhapatnam
- visakhapatnam
- Vizag
- vizag

## synonym:Thiruvananthapuram
- thiruvananthapuram
- trivandrum
- Trivandrum
- Travancore
- travancore

## synonym:Vadodara
- vadodara
- Vadodra
- vadodra

## synonym:Jamshedpur
- jamshedpur
- Jamsedpur
- jamsedpur

## synonym:Rajahmundry
- rajahmundry
- Rajahmundri
- rajahmundri
- Rajamundry
- rajamundry
- Rajamundri
- rajamundri

## synonym:Rourkela
- rourkela
- Raurkela
- raurkela
- roorkela
- Roorkela

## synonym:Amritsar
- amritsar
- Amratsar
- amratsar

## synonym:Chandigarh
- chandigarh
- Chandighar
- chandighar

## synonym:Allahabad
- prayagraj
- Prayagraj
- Allahabad
- allahabad

## synonym:Nashik
- nashik
- Nasik
- nasik

## synonym:Pondicherry
- pondicherry
- puducherry
- Puducherry

## synonym:Mumbai
- Bombay
- mumbai
- bombay
- bombai

## synonym:vegetarian
- veggie
- vegg

## regex:greet
- hey[^\s]*


## regex:pincode
- [0-9]{6}

## regex:email
- ([\w.-]+)@(([[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.)|(([\w-]+.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(]?)
